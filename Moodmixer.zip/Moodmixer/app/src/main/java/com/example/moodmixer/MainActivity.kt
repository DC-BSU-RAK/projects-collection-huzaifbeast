package com.example.moodmixer

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.ChipGroup

class MainActivity : AppCompatActivity() {

    private lateinit var moodChipGroup: ChipGroup
    private lateinit var weatherChipGroup: ChipGroup
    private lateinit var timeChipGroup: ChipGroup
    private lateinit var energyChipGroup: ChipGroup
    private lateinit var settingChipGroup: ChipGroup
    private lateinit var mixButton: MaterialButton
    private lateinit var infoButton: MaterialButton
    private lateinit var resultCard: CardView
    private lateinit var resultEmoji: TextView
    private lateinit var resultTitle: TextView
    private lateinit var resultDesc: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        moodChipGroup    = findViewById(R.id.moodChipGroup)
        weatherChipGroup = findViewById(R.id.weatherChipGroup)
        timeChipGroup    = findViewById(R.id.timeChipGroup)
        energyChipGroup  = findViewById(R.id.energyChipGroup)
        settingChipGroup = findViewById(R.id.settingChipGroup)
        mixButton        = findViewById(R.id.mixButton)
        infoButton       = findViewById(R.id.infoButton)
        resultCard       = findViewById(R.id.resultCard)
        resultEmoji      = findViewById(R.id.resultEmoji)
        resultTitle      = findViewById(R.id.resultTitle)
        resultDesc       = findViewById(R.id.resultDesc)

        mixButton.setOnClickListener {
            val mood    = getChipLabel(moodChipGroup)
            val weather = getChipLabel(weatherChipGroup)
            val time    = getChipLabel(timeChipGroup)
            val energy  = getChipLabel(energyChipGroup)
            val setting = getChipLabel(settingChipGroup)

            if (mood == null || weather == null || time == null ||
                energy == null || setting == null) {
                // At least one group has nothing selected — show a hint
                mixButton.text = "Please select all options!"
                return@setOnClickListener
            }

            mixButton.text = getString(R.string.mix_mood)
            showResult(mood, weather, time, energy, setting)
        }

        infoButton.setOnClickListener {
            android.app.AlertDialog.Builder(this)
                .setTitle("About MoodMixer")
                .setMessage(
                    "MoodMixer helps you find the perfect playlist or activity " +
                            "based on your current mood, weather, time of day, energy level, " +
                            "and setting.\n\nSelect your options and tap Mix My Mood!"
                )
                .setPositiveButton("Got it", null)
                .show()
        }
    }

    /** Returns the text of the checked chip in a ChipGroup, or null if none checked. */
    private fun getChipLabel(group: ChipGroup): String? {
        val id = group.checkedChipId
        if (id == View.NO_ID) return null
        return findViewById<com.google.android.material.chip.Chip>(id)
            .text.toString()
            .replace(Regex("[^\\p{L}\\p{N} ]"), "") // strip emoji
            .trim()
    }

    private fun showResult(
        mood: String, weather: String, time: String,
        energy: String, setting: String
    ) {
        val (emoji, title, desc) = generateMix(mood, weather, time, energy, setting)
        resultEmoji.text = emoji
        resultTitle.text = title
        resultDesc.text  = desc
        resultCard.visibility = View.VISIBLE
    }

    /**
     * Simple rule-based mix generator.
     * Expand this map with as many combinations as you like.
     */
    private fun generateMix(
        mood: String, weather: String, time: String,
        energy: String, setting: String
    ): Triple<String, String, String> {

        // High energy combos
        if (energy == "High" && setting == "Party")
            return Triple("🎉", "Party Mode Activated",
                "Time to turn it up! High-energy beats for $weather $time vibes.")

        if (energy == "Chaotic" && mood == "Energized")
            return Triple("🌀", "Controlled Chaos",
                "Unpredictable drops and wild tempo shifts — perfect for $setting.")

        // Calm / focus combos
        if (mood == "Focused" && setting == "Working")
            return Triple("🎯", "Deep Work Zone",
                "Lo-fi, ambient, or minimal beats to keep you locked in during $time.")

        if (mood == "Calm" && weather == "Rainy")
            return Triple("🌧", "Rainy Day Chill",
                "Soft piano and ambient sounds to match the $time rain outside.")

        // Romantic combos
        if (mood == "Romantic" && time == "Evening")
            return Triple("💜", "Evening Romance",
                "Smooth R&B and soul for a perfect $weather $time with someone special.")

        if (mood == "Romantic" && time == "Late Night")
            return Triple("🌙", "Midnight Serenade",
                "Slow jams and soft melodies for a $weather late night mood.")

        // Nostalgic combos
        if (mood == "Nostalgic")
            return Triple("🎞", "Memory Lane",
                "Classics and throwbacks that match that $weather $time feeling.")

        // Melancholic combos
        if (mood == "Melancholic" && weather == "Stormy")
            return Triple("⛈", "Storm & Soul",
                "Emotional indie and acoustic tracks for a stormy $time alone.")

        if (mood == "Melancholic" && weather == "Rainy")
            return Triple("🌧", "Rainy Soul",
                "Sad bangers and heartfelt lyrics for a $time rain session.")

        // Anxious
        if (mood == "Anxious")
            return Triple("😮‍💨", "Breathe Easy",
                "Calming ambient sounds and slow rhythms to ease your $time $weather nerves.")

        // Morning combos
        if (time == "Morning" && energy == "Low")
            return Triple("🌅", "Slow Morning",
                "Gentle acoustic and coffee-shop vibes to ease into the $weather day.")

        if (time == "Morning" && energy == "High")
            return Triple("☀️", "Rise & Grind",
                "Upbeat pop and motivational tracks for a $weather morning kickstart.")

        // Golden hour
        if (time == "Golden Hour")
            return Triple("✨", "Golden Hour Glow",
                "Warm indie and dreamy pop to match the most beautiful time of day.")

        // Late night
        if (time == "Late Night" && setting == "Solo")
            return Triple("🌙", "Late Night Thoughts",
                "Introspective tracks for a $weather solo $time session.")

        // Driving
        if (setting == "Driving" && energy == "High")
            return Triple("🚗", "Road Rush",
                "High-BPM anthems and bangers to fuel your $weather $time drive.")

        if (setting == "Driving")
            return Triple("🚗", "Cruise Control",
                "Smooth road-trip vibes for a $weather $time drive.")

        // With friends
        if (setting == "With Friends" && mood == "Happy")
            return Triple("👥", "Squad Vibes",
                "Feel-good hits and anthems for a $weather $time hangout.")

        // Snowy / foggy weather defaults
        if (weather == "Snowy")
            return Triple("❄️", "Winter Soundscape",
                "Cozy, warm sounds to contrast the snow outside during $time.")

        if (weather == "Foggy")
            return Triple("🌫", "Misty Atmosphere",
                "Mysterious ambient and dream-pop for a foggy $time.")

        // Generic fallback
        return Triple("🎵", "$mood × $weather",
            "A curated mix for your $mood mood on a $weather $time — enjoy the $setting session.")
    }
}