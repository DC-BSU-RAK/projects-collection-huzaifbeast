package com.quoteapp

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.quoteapp.R
class FavouriteFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_favourite, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val root      = view.findViewById<LinearLayout>(R.id.fav_root)
        val tvQuote   = view.findViewById<TextView>(R.id.tv_fav_quote)
        val tvAuthor  = view.findViewById<TextView>(R.id.tv_fav_author)
        val tvEmpty   = view.findViewById<TextView>(R.id.tv_empty)
        val card      = view.findViewById<androidx.cardview.widget.CardView>(R.id.card_fav)
        val btnRemove = view.findViewById<Button>(R.id.btn_remove)

        // Apply theme colour
        val color = when (Prefs.getTheme(requireContext())) {
            "blue"   -> Color.parseColor("#2563EB")
            "green"  -> Color.parseColor("#16A34A")
            "orange" -> Color.parseColor("#EA580C")
            else     -> Color.parseColor("#7C3AED")
        }
        root.setBackgroundColor(color)
        btnRemove.setBackgroundColor(color)

        val favIndex = Prefs.getFavIndex(requireContext())

        if (favIndex == -1) {
            // No favourite saved yet
            card.visibility   = View.GONE
            btnRemove.visibility = View.GONE
            tvEmpty.visibility = View.VISIBLE
        } else {
            // Show the saved favourite quote
            card.visibility    = View.VISIBLE
            btnRemove.visibility = View.VISIBLE
            tvEmpty.visibility = View.GONE

            val q = ALL_QUOTES[favIndex]
            tvQuote.text  = "\u201C${q.text}\u201D"
            tvAuthor.text = "— ${q.author}"

            // Remove favourite button
            btnRemove.setOnClickListener {
                Prefs.setFavIndex(requireContext(), -1)
                Toast.makeText(requireContext(), "Favourite removed", Toast.LENGTH_SHORT).show()
                // Refresh this fragment
                parentFragmentManager.beginTransaction()
                    .replace(R.id.fragment_container, FavouriteFragment())
                    .commit()
            }
        }
    }
}