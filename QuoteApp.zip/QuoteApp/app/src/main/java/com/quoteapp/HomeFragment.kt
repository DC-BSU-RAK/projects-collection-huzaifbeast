package com.quoteapp

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.cardview.widget.CardView
import androidx.fragment.app.Fragment
import com.quoteapp.R
class HomeFragment : Fragment() {

    private var currentIndex = 0

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val card      = view.findViewById<CardView>(R.id.card_quote)
        val tvQuote   = view.findViewById<TextView>(R.id.tv_quote)
        val tvAuthor  = view.findViewById<TextView>(R.id.tv_author)
        val tvCounter = view.findViewById<TextView>(R.id.tv_counter)
        val btnNext   = view.findViewById<Button>(R.id.btn_next)
        val btnStar   = view.findViewById<ImageButton>(R.id.btn_star)
        val tvSaved   = view.findViewById<TextView>(R.id.tv_saved_badge)
        val root      = view.findViewById<LinearLayout>(R.id.home_root)

        // Apply saved theme colour to background
        val themeColor = getThemeColor()
        root.setBackgroundColor(themeColor)
        btnNext.setBackgroundColor(themeColor)

        // Load last viewed quote index
        currentIndex = Prefs.getLastIndex(requireContext())

        fun refresh() {
            val q = ALL_QUOTES[currentIndex]
            tvQuote.text  = "\u201C${q.text}\u201D"
            tvAuthor.text = "— ${q.author}"
            tvCounter.text = "${currentIndex + 1} / ${ALL_QUOTES.size}"
            // Show badge if this is the saved favourite
            tvSaved.visibility = if (Prefs.getFavIndex(requireContext()) == currentIndex)
                View.VISIBLE else View.GONE
            // Star icon: filled or outline
            btnStar.setImageResource(
                if (Prefs.getFavIndex(requireContext()) == currentIndex)
                    android.R.drawable.btn_star_big_on
                else
                    android.R.drawable.btn_star_big_off
            )
        }

        refresh()

        // Next button: pick a random different quote, animate the card
        btnNext.setOnClickListener {
            val fadeOut = AnimationUtils.loadAnimation(requireContext(), R.anim.fade_out)
            val fadeIn  = AnimationUtils.loadAnimation(requireContext(), R.anim.fade_in)
            card.startAnimation(fadeOut)
            card.postDelayed({
                var next = currentIndex
                while (next == currentIndex) next = (ALL_QUOTES.indices).random()
                currentIndex = next
                Prefs.setLastIndex(requireContext(), currentIndex)
                refresh()
                card.startAnimation(fadeIn)
            }, 260)
        }

        // Star button: save or remove favourite
        btnStar.setOnClickListener {
            if (Prefs.getFavIndex(requireContext()) == currentIndex) {
                Prefs.setFavIndex(requireContext(), -1)
                Toast.makeText(requireContext(), "Removed from favourites", Toast.LENGTH_SHORT).show()
            } else {
                Prefs.setFavIndex(requireContext(), currentIndex)
                Toast.makeText(requireContext(), "Saved as favourite ★", Toast.LENGTH_SHORT).show()
            }
            refresh()
        }
    }

    // Returns an Int colour based on the saved theme name
    private fun getThemeColor(): Int = when (Prefs.getTheme(requireContext())) {
        "blue"   -> Color.parseColor("#2563EB")
        "green"  -> Color.parseColor("#16A34A")
        "orange" -> Color.parseColor("#EA580C")
        else     -> Color.parseColor("#7C3AED") // default purple
    }
}