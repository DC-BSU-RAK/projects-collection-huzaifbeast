package com.quoteapp

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.quoteapp.R
class SettingsFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_settings, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val root        = view.findViewById<LinearLayout>(R.id.settings_root)
        val btnPurple   = view.findViewById<Button>(R.id.btn_purple)
        val btnBlue     = view.findViewById<Button>(R.id.btn_blue)
        val btnGreen    = view.findViewById<Button>(R.id.btn_green)
        val btnOrange   = view.findViewById<Button>(R.id.btn_orange)
        val tvCurrent   = view.findViewById<TextView>(R.id.tv_current_theme)

        fun applyBg() {
            val color = when (Prefs.getTheme(requireContext())) {
                "blue"   -> Color.parseColor("#2563EB")
                "green"  -> Color.parseColor("#16A34A")
                "orange" -> Color.parseColor("#EA580C")
                else     -> Color.parseColor("#7C3AED")
            }
            root.setBackgroundColor(color)
            tvCurrent.text = "Current theme: ${Prefs.getTheme(requireContext()).replaceFirstChar { it.uppercase() }}"
        }

        applyBg()

        // Each button saves the theme and updates the background immediately
        btnPurple.setOnClickListener {
            Prefs.setTheme(requireContext(), "purple")
            applyBg()
            Toast.makeText(requireContext(), "Theme set to Purple", Toast.LENGTH_SHORT).show()
        }
        btnBlue.setOnClickListener {
            Prefs.setTheme(requireContext(), "blue")
            applyBg()
            Toast.makeText(requireContext(), "Theme set to Blue", Toast.LENGTH_SHORT).show()
        }
        btnGreen.setOnClickListener {
            Prefs.setTheme(requireContext(), "green")
            applyBg()
            Toast.makeText(requireContext(), "Theme set to Green", Toast.LENGTH_SHORT).show()
        }
        btnOrange.setOnClickListener {
            Prefs.setTheme(requireContext(), "orange")
            applyBg()
            Toast.makeText(requireContext(), "Theme set to Orange", Toast.LENGTH_SHORT).show()
        }
    }
}