package com.quoteapp

import android.content.Context

// One quote object
data class Quote(val text: String, val author: String)

// All 20 quotes used across the whole app
val ALL_QUOTES = listOf(
    Quote("The only way to do great work is to love what you do.", "Steve Jobs"),
    Quote("In the middle of every difficulty lies opportunity.", "Albert Einstein"),
    Quote("It does not matter how slowly you go as long as you do not stop.", "Confucius"),
    Quote("Life is what happens when you're busy making other plans.", "John Lennon"),
    Quote("The future belongs to those who believe in the beauty of their dreams.", "Eleanor Roosevelt"),
    Quote("Spread love everywhere you go.", "Mother Teresa"),
    Quote("You must be the change you wish to see in the world.", "Mahatma Gandhi"),
    Quote("A journey of a thousand miles begins with a single step.", "Lao Tzu"),
    Quote("Believe you can and you're halfway there.", "Theodore Roosevelt"),
    Quote("Success is not final, failure is not fatal: it is the courage to continue that counts.", "Winston Churchill"),
    Quote("You only live once, but if you do it right, once is enough.", "Mae West"),
    Quote("In three words I can sum up everything I've learned about life: it goes on.", "Robert Frost"),
    Quote("That which does not kill us makes us stronger.", "Friedrich Nietzsche"),
    Quote("The best time to plant a tree was 20 years ago. The second best time is now.", "Chinese Proverb"),
    Quote("An unexamined life is not worth living.", "Socrates"),
    Quote("To be yourself in a world constantly trying to make you something else is the greatest accomplishment.", "Ralph Waldo Emerson"),
    Quote("Don't judge each day by the harvest you reap but by the seeds that you plant.", "Robert Louis Stevenson"),
    Quote("Always remember that you are absolutely unique, just like everyone else.", "Margaret Mead"),
    Quote("When you reach the end of your rope, tie a knot and hang on.", "Franklin D. Roosevelt"),
    Quote("Spread your wings and let the fairy in you fly.", "Mariah Carey")
)

// Simple helper so every fragment reads/writes the same prefs file
object Prefs {
    private const val FILE = "quote_prefs"

    fun get(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // Last quote index shown on Home screen
    fun getLastIndex(ctx: Context)        = get(ctx).getInt("last_index", 0)
    fun setLastIndex(ctx: Context, i: Int) = get(ctx).edit().putInt("last_index", i).apply()

    // Favourite quote index (-1 = none saved)
    fun getFavIndex(ctx: Context)           = get(ctx).getInt("fav_index", -1)
    fun setFavIndex(ctx: Context, i: Int)   = get(ctx).edit().putInt("fav_index", i).apply()

    // Theme colour name ("purple" / "blue" / "green" / "orange")
    fun getTheme(ctx: Context)              = get(ctx).getString("theme", "purple") ?: "purple"
    fun setTheme(ctx: Context, t: String)   = get(ctx).edit().putString("theme", t).apply()
}